# Hardware selftest firmware for RSL1000 - Arrow OnSemi BT5.0 IoT Board
