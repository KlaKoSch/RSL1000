/* ----------------------------------------------------------------------------
 * Copyright (c) 2019 Semiconductor Components Industries, LLC (d/b/a
 * ON Semiconductor), All Rights Reserved
 *
 * This code is the property of ON Semiconductor and may not be redistributed
 * in any form without prior written permission from ON Semiconductor.
 * The terms of use and warranty for this code are covered by contractual
 * agreements between ON Semiconductor and the licensee.
 *
 * This is Reusable Code.
 *
 * ----------------------------------------------------------------------------
 * app.c
 *  - This modified application demonstrates the use I2C CMSIS-Driver to operate
 *    the I2C interface. It configures the I2C as master and communicate with
 *    some periperals on the RSL1000 board.
 *    A new part of demo starts, when the button (DIO5) is pressed.
 * ------------------------------------------------------------------------- */

#include "app.h"
#include <printf.h>
#include "rsl1000.h"

/* Global variables */
DRIVER_GPIO_t *gpio;
ARM_DRIVER_I2C *i2c;

/* used for program control and I2C communication */
volatile uint32_t button_pressed = false; // Flag for pressed button

/* ----------------------------------------------------------------------------
 * Function      : void Button_EventCallback(uint32_t event)
 * ----------------------------------------------------------------------------
 * Description   : Interrupt handler triggered by a button press. Cancel any
 *                 ongoing transfers, switch to Master mode and start a
 *                 MasterTransmit operation through I2C.
 * Inputs        : event - event number which triggered the callback
 * Outputs       : None
 * Assumptions   : None
 * ------------------------------------------------------------------------- */
void Button_EventCallback(uint32_t event)
{
    static bool ignore_next_dio_int = false;
    if (ignore_next_dio_int)
    {
        ignore_next_dio_int = false;
    }
    /* Button is pressed: Ignore next interrupt.
     * This is required to deal with the debounce circuit limitations. */
    else if (event == GPIO_EVENT_0_IRQ)
    {
		ignore_next_dio_int = true;
		button_pressed = true;
    }
}

/* ----------------------------------------------------------------------------
 * Function      : void I2C_CallBack(uint32_t event)
 * ----------------------------------------------------------------------------
 * Description   : This function is a callback registered by the function
 *                 Initialize. The parameter event indicates one or more events
 *                 that occurred during driver operation.
 * Inputs        : event - I2C Events notification mask
 * Outputs       : None
 * Assumptions   : None
 * ------------------------------------------------------------------------- */
void I2C_EventCallback(uint32_t event)
{
    static volatile uint32_t I2C_Event;
    I2C_Event |= event;

    /* Refresh the watchdog */
    Sys_Watchdog_Refresh();

    /* Check if transfer error occurred */
    if ((event & ARM_I2C_EVENT_TRANSFER_INCOMPLETE) || (event & ARM_I2C_EVENT_BUS_ERROR))
    {
        /* Abort current transfer */
        i2c->Control(ARM_I2C_ABORT_TRANSFER, 0);

        /* Error Message */
        PRINTF("TRANSFER INCOMPLETE OR BUS ERROR\n");

        /* Toggle LED at 100 milliseconds to indicate error */
        while(1)
        {
            /* Refresh the watchdog */
            Sys_Watchdog_Refresh();
            ToggleLed(1, 100);
        }
    }
}

/* ----------------------------------------------------------------------------
 * Function      : void ToggleLed(uint32_t n, uint32_t delay_ms)
 * ----------------------------------------------------------------------------
 * Description   : Toggle the led pin.
 * Inputs        : n        - number of toggles
 *               : delay_ms - delay between each toggle [ms]
 * Outputs       : None
 * Assumptions   : None
 * ------------------------------------------------------------------------- */
void ToggleLed(uint32_t n, uint32_t delay_ms)
{
    for (; n > 0; n--)
    {
        /* Refresh the watchdog */
        Sys_Watchdog_Refresh();

        /* Toggle led diode */
        gpio->ToggleValue(RSL1000_LED);

        /* Delay */
        Sys_Delay_ProgramROM((delay_ms / 1000.0) * SystemCoreClock);
    }
}

/* ----------------------------------------------------------------------------
 * Function      : void Initialize(void)
 * ----------------------------------------------------------------------------
 * Description   : Initialize the system by disabling interrupts, switching to
 *                 the 48 MHz clock and configuring the required DIOs to use
 *                 the i2c.
 * Inputs        : None
 * Outputs       : None
 * Assumptions   : None
 * ------------------------------------------------------------------------- */
void Initialize(void)
{
    /* Mask all interrupts */
    __set_PRIMASK(PRIMASK_DISABLE_INTERRUPTS);

    /* Disable all existing interrupts, clearing all pending source */
    Sys_NVIC_DisableAllInt();
    Sys_NVIC_ClearAllPendingInt();

    /* Test DIO12 to pause the program to make it easy to re-flash */
    DIO->CFG[RECOVERY_DIO] = DIO_MODE_INPUT  | DIO_WEAK_PULL_UP |
                             DIO_LPF_DISABLE | DIO_6X_DRIVE;
    while (DIO_DATA->ALIAS[RECOVERY_DIO] == 0);

    /* Prepare the 48 MHz crystal
     * Start and configure VDDRF */
    ACS_VDDRF_CTRL->ENABLE_ALIAS = VDDRF_ENABLE_BITBAND;
    ACS_VDDRF_CTRL->CLAMP_ALIAS  = VDDRF_DISABLE_HIZ_BITBAND;

    /* Wait until VDDRF supply has powered up */
    while (ACS_VDDRF_CTRL->READY_ALIAS != VDDRF_READY_BITBAND);

    /* Enable RF power switches */
    SYSCTRL_RF_POWER_CFG->RF_POWER_ALIAS   = RF_POWER_ENABLE_BITBAND;

    /* Remove RF isolation */
    SYSCTRL_RF_ACCESS_CFG->RF_ACCESS_ALIAS = RF_ACCESS_ENABLE_BITBAND;

    /* Start the 48 MHz oscillator without changing the other register bits */
    RF->XTAL_CTRL = ((RF->XTAL_CTRL & ~XTAL_CTRL_DISABLE_OSCILLATOR) |
                     XTAL_CTRL_REG_VALUE_SEL_INTERNAL);

    /* Enable 48 MHz oscillator divider at desired prescale value */
    RF_REG2F->CK_DIV_1_6_CK_DIV_1_6_BYTE = CK_DIV_1_6_PRESCALE_1_BYTE;

    /* Wait until 48 MHz oscillator is started */
    while (RF_REG39->ANALOG_INFO_CLK_DIG_READY_ALIAS !=
           ANALOG_INFO_CLK_DIG_READY_BITBAND);

    /* Switch to 48 MHz oscillator clock */
    Sys_Clocks_SystemClkConfig(JTCK_PRESCALE_1   |
                               EXTCLK_PRESCALE_1 |
                               SYSCLK_CLKSRC_RFCLK);

	/* Disable unused JTAG Pin */
	 DIO_JTAG_SW_PAD_CFG->CM3_JTAG_DATA_EN_ALIAS = 0;

    /* Initialize gpio structure */
    gpio = &Driver_GPIO;

    /* Initialize gpio driver */
    gpio->Initialize(Button_EventCallback);

    /* Stop masking interrupts */
    __set_PRIMASK(PRIMASK_ENABLE_INTERRUPTS);
    __set_FAULTMASK(FAULTMASK_ENABLE_INTERRUPTS);

    /* Initalize UART/RTT */
    printf_init();

    /* Initialize i2c driver structure */
    i2c = &Driver_I2C0;

    /* Initialize i2c, register callback function */
    i2c->Initialize(I2C_EventCallback);

    /* Initialize I/O-Expander */
    pca9655_init(i2c, RSL1000_IOEXP_ADDRESS);
    pca9655_port_dir(RSL1000_IOEXP_LED_PORT, (uint8_t) ~RSL1000_IOEXP_LEDS_MASK);
    pca9655_port_set(RSL1000_IOEXP_LED_PORT, (uint8_t) ~RSL1000_IOEXP_LEDS_MASK);

    /* RGB LED driver */
    ncp5623_init(i2c, RSL1000_RGBLED_ADDRESS);
    ncp5623_off();
    ncp5623_color(0,0,0);

    /* Ambient light sensor */
    noa1305_init(i2c, RSL1000_ALS_ADDRESS);
    noa1305_power(0);

    /* Initialize Accelerometer */
    lis3dh_init(i2c, RSL1000_ACC_ADDRESS);
    lis3dh_power(0x02, false, true, true, true);
}

/* ----------------------------------------------------------------------------
 * Function      : void RGB_Demo(void)
 * ----------------------------------------------------------------------------
 * Description   : Color wheel on RGB led
 * Inputs        : None
 * Outputs       : None
 * Assumptions   : Exit if button pressed
 * ------------------------------------------------------------------------- */
void RGB_Demo(void)
{
    int     brightness;

    button_pressed = false;

    PRINTF("\n RGB LED demo\n");

    PRINTF(" - LED current 100%\n");
    ncp5623_iled(0x1f);

    while(button_pressed == false)
    {
    	/* Show red LEDs */
	    PRINTF(" - Red PWM\n");
	    brightness = 0;
    	while((brightness < 0x20) & (button_pressed == false))
    	{
    		ncp5623_color(brightness++, 0, 0);
    	    Sys_Delay_ProgramROM((50 / 1000.0) * SystemCoreClock);
    	}
		ncp5623_color(0, 0, 0);
	    Sys_Delay_ProgramROM((50 / 1000.0) * SystemCoreClock);

    	/* Show green LEDs */
	    PRINTF(" - Green PWM\n");
	    brightness = 0;
    	while((brightness < 0x20) & (button_pressed == false))
    	{
    		ncp5623_color(0, brightness++, 0);
    	    Sys_Delay_ProgramROM((50 / 1000.0) * SystemCoreClock);
    	}
		ncp5623_color(0, 0, 0);
	    Sys_Delay_ProgramROM((50 / 1000.0) * SystemCoreClock);

    	/* Show blue LEDs */
    	PRINTF(" - Blue PWM\n");
    	brightness = 0;
    	while((brightness < 0x20) & (button_pressed == false))
    	{
    		ncp5623_color(0, 0, brightness++);
    	    Sys_Delay_ProgramROM((50 / 1000.0) * SystemCoreClock);
    	}
		ncp5623_color(0, 0, 0);
	    Sys_Delay_ProgramROM((50 / 1000.0) * SystemCoreClock);

    	/* Show all RGB LEDs */
	    PRINTF(" - All LEDs\n");
	    brightness = 0;
    	while((brightness < 0x20) & (button_pressed == false))
    	{
    		ncp5623_color(brightness, brightness, brightness);
    	    brightness++;
    	    Sys_Delay_ProgramROM((50 / 1000.0) * SystemCoreClock);
    	}

    	/* Reset all LEDs */
		ncp5623_color(0, 0, 0);
	    Sys_Delay_ProgramROM((50 / 1000.0) * SystemCoreClock);
    }
}

/* ----------------------------------------------------------------------------
 * Function      : void LED_Demo(void)
 * ----------------------------------------------------------------------------
 * Description   : Running light on four red LEDs
 * Inputs        : None
 * Outputs       : None
 * Assumptions   : Exit if button pressed
 * ------------------------------------------------------------------------- */
void LED_Demo(void)
{
    int     led = 0x10;

    PRINTF("\n LED demo\n");
    button_pressed = false;

    while(button_pressed == false)
    {
        PRINTF(" - next LED\n");
        pca9655_port_set(1, led);
        Sys_Delay_ProgramROM((200 / 1000.0) * SystemCoreClock);

	    if(led == 0x80)		// last led ?
	    	led = 0x10; 	//  - back to first led
	    else
	    	led = led << 1; //  - next led
	}

    /* Switch off all LEDs */
    pca9655_port_set(1, 0);
    Sys_Delay_ProgramROM((200 / 1000.0) * SystemCoreClock);
}

/* ----------------------------------------------------------------------------
 * Function      : void ALS_Demo(void)
 * ----------------------------------------------------------------------------
 * Description   : show ALS value
 * Inputs        : None
 * Outputs       : None
 * Assumptions   : Exit if button pressed
 * ------------------------------------------------------------------------- */
void ALS_Demo(void)
{
    uint16_t brightness;
    uint8_t rgb[3];
    button_pressed = false;

    PRINTF("\n ALS demo\n");
    noa1305_power(1);
    noa1305_time(time_50ms);

    while(button_pressed == false)
    {
    	brightness = noa1305_read();

    	rgb[0] = 0;
    	rgb[1] = 0;
    	rgb[2] = 0;
    	if(brightness >> 10){
    		rgb[0] = (brightness >> 10) & 0x1f;
    	}
    	else if((brightness >> 5) & 0x1f){
   			rgb[1] = (brightness >> 5) & 0x1f;
   		}
   		else{
   			rgb[2] = brightness & 0x1f;
   		}

    	/* Show value on terminal */
    	PRINTF(" - Value : %i\n", brightness);

    	/* and RGB LED */
		ncp5623_color(rgb[0], rgb[1], rgb[2]);
		Sys_Delay_ProgramROM((200 / 1000.0) * SystemCoreClock);
    }

    /* Switch off ALS */
    noa1305_power(0);

	/* Reset all LEDs */
	ncp5623_color(0, 0, 0);
    Sys_Delay_ProgramROM((50 / 1000.0) * SystemCoreClock);
}

/* ----------------------------------------------------------------------------
 * Function      : void LIS_Demo(void)
 * ----------------------------------------------------------------------------
 * Description   : show LIS3D value (x/y/z)
 * Inputs        : None
 * Outputs       : None
 * Assumptions   : Exit if button pressed
 * ------------------------------------------------------------------------- */
uint8_t scale(int16_t value)
{
	if(value >= 0)
		return value / 2048;
	else
		return (0 - value) / 2048;
}

void LIS_Demo(void)
{
    int16_t val[3];
    uint8_t rgb[3];
    button_pressed = false;

    PRINTF("\n LIS demo\n");
	lis3dh_power(2, 0, 1, 1, 1); // 10Hz, normal mode, x/y/z activ

    while(button_pressed == false)
    {
    	lis3dh_out(&val[0], &val[1], &val[2]);

    	rgb[0] = scale(val[0]);
    	rgb[1] = scale(val[1]);
    	rgb[2] = scale(val[2]);

    	/* Show value on terminal */
    	PRINTF(" - Value : %6d / %6d / %6d\n", val[0], val[1], val[2]);

    	/* and RGB LED */
		ncp5623_color(rgb[0], rgb[1], rgb[2]);
		Sys_Delay_ProgramROM((200 / 1000.0) * SystemCoreClock);
    }

	/* Reset all LEDs */
	ncp5623_color(0, 0, 0);
    Sys_Delay_ProgramROM((50 / 1000.0) * SystemCoreClock);
}

/* ----------------------------------------------------------------------------
 * Function      : int main(void)
 * ----------------------------------------------------------------------------
 * Description   : Initialize the system ans drivers, then send an I2C frame
                   controlled on button press.
 * Inputs        : None
 * Outputs       : None
 * Assumptions   : None
 * ------------------------------------------------------------------------- */
int main(void)
{

    /* Initialize the clocks and configure button press interrupt */
    Initialize();

    PRINTF("DEVICE INITIALIZED\n");

    /* Spin loop */
    while (true)
    {
        RGB_Demo();
    	LED_Demo();
    	ALS_Demo();
    	LIS_Demo();
    }
}
