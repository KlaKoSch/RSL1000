#ifndef RSL1000_H_
#define RSL1000_H_

#include "pca9655.h"
#include "ncp5623.h"
#include "noa1305.h"
#include "lis3dh.h"

#define CONCAT(x, y)            x##y
#define DIO_SRC(x)              CONCAT(DIO_SRC_DIO_, x)

/* On board LED and button definitions */
#define RSL1000_LED	            6  /* DIO6_LED */
#define RSL1000_S2_BUTTON       5  /* DIO5_BTN */
#define RSL1000_S3_BUTTON       12 /* DIO12_BTN */

/* Accerator sensor I2C address */
#define RSL1000_ACC_ADDRESS     0x18

/* IO Expander */
#define RSL1000_IOEXP_ADDRESS   0x20

#define RSL1000_IOEXP_LED_PORT  1
#define RSL1000_IOEXP_LEDS_MASK 0xF0
#define RSL1000_IOEXP_LED1      0x80
#define RSL1000_IOEXP_LED2      0x40
#define RSL1000_IOEXP_LED3      0x20
#define RSL1000_IOEXP_LED4      0x10

/* RGB LED driver */
#define RSL1000_RGBLED_ADDRESS  0x38

/* Ambient light sensor */
#define RSL1000_ALS_ADDRESS     0x39

#endif /* RSL1000_H_ */
