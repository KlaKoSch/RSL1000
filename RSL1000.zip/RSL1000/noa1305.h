#ifndef NOA1305_H_
#define NOA1305_H_

#include <Driver_I2C.h>
#include <stdint.h>

enum {
	time_800ms,
	time_400ms,
	time_200ms,
	time_100ms,
	time_50ms,
	time_25ms,
	time_12ms,
	time_6ms
} ALS_time;

int noa1305_init(ARM_DRIVER_I2C* bus, uint8_t address);
uint16_t noa1305_device_id(void);
void noa1305_power(uint8_t on);
void noa1305_time(uint8_t time);
uint16_t noa1305_read(void);

#endif /* NOA1305_H_ */
